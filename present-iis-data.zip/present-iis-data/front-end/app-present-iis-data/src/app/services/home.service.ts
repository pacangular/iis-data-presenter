import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LogFile } from '../models/log-file';

@Injectable({
  providedIn: 'root',
})
export class HomeService {
  constructor(private client: HttpClient) {}

  getAvailableLogFiles(): Observable<LogFile[]> {
    return this.client.get<LogFile[]>(environment.apiBaseUrl + "log-presenter/GetListOfFiles");
  }
}
