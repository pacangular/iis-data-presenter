import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LogFileData } from '../models/log-file-data';

@Injectable({
  providedIn: 'root'
})
export class DataPresenterService {

  constructor(private client: HttpClient) {}

  getDataForFile(fileName: string): Observable<LogFileData[]> {
    let url = environment.apiBaseUrl + "log-presenter/GetDataForFile?fileName=" + fileName;
    return this.client.get<LogFileData[]>(url);
  }
}
