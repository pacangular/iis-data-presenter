import { TestBed } from '@angular/core/testing';

import { DataPresenterService } from './data-presenter.service';

describe('DataPresenterService', () => {
  let service: DataPresenterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataPresenterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
