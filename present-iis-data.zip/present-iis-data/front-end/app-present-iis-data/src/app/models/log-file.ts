export class LogFile {
    fileName: string | undefined;
}