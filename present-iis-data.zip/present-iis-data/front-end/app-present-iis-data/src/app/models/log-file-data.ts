export class LogFileData {
  /**
   *
   */
  /**
   *
   */
  constructor(
    clientIp: string | undefined,
    fqdn: string | undefined,
    numberOfCalls: number | undefined
  ) {
      this.clientIp = clientIp;
      this.fqdn = fqdn;
      this.numberOfCalls = numberOfCalls;
  }
  
  clientIp: string | undefined;
  fqdn: string | undefined;
  numberOfCalls: number | undefined;
}
