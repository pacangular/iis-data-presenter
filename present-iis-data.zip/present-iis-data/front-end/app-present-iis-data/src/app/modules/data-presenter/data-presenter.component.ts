import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { LogFileData } from 'src/app/models/log-file-data';
import { DataPresenterService } from 'src/app/services/data-presenter.service';

@Component({
  selector: 'app-data-presenter',
  templateUrl: './data-presenter.component.html',
  styleUrls: ['./data-presenter.component.scss'],
})
export class DataPresenterComponent implements OnInit, OnDestroy {
  routingSubscription: Subscription;
  fileName: string  | null = null;
  data$: Observable<LogFileData[]> = new Observable<LogFileData[]>();
  displayedColumns: string[] = ['clientIp', 'fqdn', 'numberOfCalls',];

  constructor(private activatedRoute: ActivatedRoute, private router: Router, private service: DataPresenterService) {
    this.routingSubscription = this.activatedRoute.paramMap.subscribe(
      (params: ParamMap) => {
        const fileName: string | null = params.get('fileName');

        if (fileName) {
          this.fileName = fileName;
        }
      }
    );
  }

  ngOnInit(): void {
    if (this.fileName) {
      this.data$ = this.service.getDataForFile(this.fileName);
    }
    else {
      this.router.navigate(['/home'])
    }
  }
  
  ngOnDestroy(): void {
    this.routingSubscription.unsubscribe();
  }
}
