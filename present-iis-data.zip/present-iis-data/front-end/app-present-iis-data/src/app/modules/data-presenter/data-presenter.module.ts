import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DataPresenterRoutingModule } from './data-presenter-routing.module';
import { DataPresenterComponent } from './data-presenter.component';
import { DataPresenterService } from 'src/app/services/data-presenter.service';
import { MatIconModule } from '@angular/material/icon';
import {MatTableModule} from '@angular/material/table';


@NgModule({
  declarations: [
    DataPresenterComponent
  ],
  imports: [
    CommonModule,
    DataPresenterRoutingModule,
    MatIconModule,
    MatTableModule
  ],
  providers: [
    DataPresenterService
  ]
})
export class DataPresenterModule { }
