import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DataPresenterComponent } from './data-presenter.component';

const routes: Routes = [
  { 
    path: '', component: DataPresenterComponent 
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DataPresenterRoutingModule {}
