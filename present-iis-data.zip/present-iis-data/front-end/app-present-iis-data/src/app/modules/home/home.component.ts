import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { LogFile } from 'src/app/models/log-file';
import { HomeService } from 'src/app/services/home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  logFiles$: Observable<LogFile[]> | null = null;


  constructor(private service: HomeService) { }

  ngOnInit(): void {
    this.logFiles$ = this.service.getAvailableLogFiles();
  }

}
