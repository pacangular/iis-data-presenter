using System.Text;

public class LogDeconstructor
{
    private const string relativePathToFolder = "./Data";
    private const string keyForServerIpColumn = "s-ip";
    private const string keyForClientIpColumn = "c-ip";
    private static LogDeconstructor instance = null;
    private Dictionary<string, IEnumerable<LogFileData>> logFiles;
    private LogDeconstructor()
    {
        this.logFiles = new Dictionary<string, IEnumerable<LogFileData>>();
    }
    public static LogDeconstructor GetLogDeconstructor()
    {
        if (instance == null)
        {
            instance = new LogDeconstructor();
        }

        return instance;
    }

    public IEnumerable<LogFile> GetListOfLogFiles()
    {
        var result = Directory.EnumerateFiles(relativePathToFolder, "*.log")
                        ?.Select(x => x.Substring(x.LastIndexOf("\\") + 1))
                        ?.OrderBy(x => x)
                        ?.Select(x => new LogFile() { FileName = x });

        return result;
    }

    public IEnumerable<LogFileData> GetDataForFile(string fileName)
    {
        IEnumerable<LogFileData> result = null;
        this.logFiles.TryGetValue(fileName, out result);

        if (result == null)
        {
            var fileContent = System.IO.File.ReadAllText(relativePathToFolder + "\\" + fileName);
            if (fileContent != null)
            {
                this.logFiles.Add(fileName, this.GetFormatedData(fileContent));
            }
        }

        return result ?? this.logFiles[fileName];
    }

    private IEnumerable<LogFileData> GetFormatedData(string content, int initialIndex = 0, IEnumerable<LogFileData> combinedSet = null)
    {
        var startIndex = content.IndexOf("#Fields:", initialIndex);
        var endIndexForHeader = content.IndexOf(Environment.NewLine, startIndex);
        var endIndexForContent = content.IndexOf("#Software", endIndexForHeader);

        if (endIndexForContent == -1)
        {
            endIndexForContent = content.Length - 1;
        }

        var availableFields = content.Substring(startIndex, endIndexForHeader - startIndex).Split(' ', StringSplitOptions.RemoveEmptyEntries);

        int indexOfServerIp = -1, indexOfClientIp = -1;
        for (int i = 0; i < availableFields.Count(); i++)
        {
            if (availableFields[i] == keyForServerIpColumn)
            {
                indexOfServerIp = i - 1;
            }

            if (availableFields[i] == keyForClientIpColumn)
            {
                indexOfClientIp = i - 1;
            }
        }

        if (indexOfServerIp == -1 || indexOfClientIp == -1)
        {
            return null;
        }

        var availableData = content.Substring(endIndexForHeader, endIndexForContent - endIndexForHeader)
                .Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Split(' ', StringSplitOptions.RemoveEmptyEntries));

        var result = combinedSet?.ToHashSet() ?? new HashSet<LogFileData>();
        foreach (var row in availableData)
        {
            var rowData = new LogFileData() { ClientIp = row[indexOfClientIp], Fqdn = row[indexOfServerIp] };
            LogFileData? resultData = null;
            if (result.TryGetValue(rowData, out resultData))
            {
                resultData.NumberOfCalls++;
            }
            else
            {
                rowData.Equals(resultData);
                result.Add(rowData);
            }
        }

        if (endIndexForContent != content.Length - 1)
        {
            return this.GetFormatedData(content, endIndexForContent, result);
        }

        return result;
    }
}