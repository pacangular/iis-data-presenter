public class LogFile {
    public string FileName { get; set; }
}