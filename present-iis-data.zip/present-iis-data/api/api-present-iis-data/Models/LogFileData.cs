using System.Diagnostics.CodeAnalysis;

public class LogFileData : IEquatable<LogFileData>, IEqualityComparer<LogFileData> {
    public LogFileData()
    {
        this.NumberOfCalls = 1;
    }

    public string? ClientIp { get; set; }
    public string? Fqdn { get; set; }
    public int NumberOfCalls { get; set; }

    public bool Equals(LogFileData? other)
    {
        if (this.ClientIp != other?.ClientIp)
        {
            return false;
        }

        if (this.Fqdn != other?.Fqdn)
        {
            return false;
        }

        return true;
    }

    public bool Equals(LogFileData? x, LogFileData? y)
    {
        if (x == null || y == null)
        {
            return false;
        }

        return x.Equals(y);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(this.ClientIp, this.Fqdn);
    }

    public int GetHashCode([DisallowNull] LogFileData obj)
    {
        return HashCode.Combine(obj.ClientIp, obj.Fqdn);
    }
}