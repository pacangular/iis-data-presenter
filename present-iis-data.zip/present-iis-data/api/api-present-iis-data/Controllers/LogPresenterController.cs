using Microsoft.AspNetCore.Mvc;

namespace api_present_iis_data.Controllers;

[ApiController]
[Route("api/log-presenter")]
public class LogPresenterController : ControllerBase
{    private LogDeconstructor service;

    public LogPresenterController()
    {
        this.service = LogDeconstructor.GetLogDeconstructor();
    }

    [HttpGet]
    [Route("GetListOfFiles")]
    public ActionResult<IEnumerable<LogFile>> GetListOfFiles()
    {
        return new ActionResult<IEnumerable<LogFile>>(this.service.GetListOfLogFiles()) ;
    }

    [HttpGet()]
    [Route("GetDataForFile")]
    public ActionResult<IEnumerable<LogFileData>> GetDataForFile(string fileName)
    {
        var result = this.service.GetDataForFile(fileName);
        return new ActionResult<IEnumerable<LogFileData>>(result) ;
    }
}